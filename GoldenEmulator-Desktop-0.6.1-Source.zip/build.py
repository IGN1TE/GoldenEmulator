from pathlib import Path
import base64
root = Path(__file__).resolve().parent
shell = (root/'src/shell.html').read_text().replace('<!-- BRAND_ICON -->','data:image/png;base64,'+base64.b64encode((root/'GoldenEmulator-logo.png').read_bytes()).decode())
css = (root/'src/stage2.css').read_text()
script = (root/'src/art.js').read_text() + (root/'src/native.js').read_text() + (root/'src/app.js').read_text() + (root/'src/controller.js').read_text()
(root/'GoldenEmulator.html').write_text(shell.replace('</style>', css+'\n</style>').replace('<!-- APP_SCRIPT -->','<script>\n'+script+'\n</script>'))
print('Built GoldenEmulator.html')
