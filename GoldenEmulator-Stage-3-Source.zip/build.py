from pathlib import Path
root = Path(__file__).resolve().parent
shell = (root/'src/shell.html').read_text()
css = (root/'src/stage2.css').read_text()
script = (root/'src/art.js').read_text() + (root/'src/native.js').read_text() + (root/'src/app.js').read_text()
(root/'GoldenEmulator.html').write_text(shell.replace('</style>', css+'\n</style>').replace('<!-- APP_SCRIPT -->','<script>\n'+script+'\n</script>'))
print('Built GoldenEmulator.html')
